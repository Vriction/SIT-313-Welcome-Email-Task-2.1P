const express = require ("express")
const app = express()

const bodyParse = require("body-parser")

app.use(bodyParse.urlencoded({extended:true}))
app.get('/', (req, res )=>
{
    res.sendFile(__dirname + "/index.html")
    //res.send("<h1>Welcome bro</h1>")
    //console.log(req)
})


app.post ('/', (req,res)=>
{
    const email = req.body.email
    console.log(email)
})


app.listen(3000, function(request, response)
{
    console.log("Server is running on port 3000")
})